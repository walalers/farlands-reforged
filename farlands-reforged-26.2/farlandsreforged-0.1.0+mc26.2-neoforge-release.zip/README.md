# Farlands Reforged

A tiny NeoForge `26.2` mod that restores classic Far Lands-style terrain generation by preserving full coordinate precision in Minecraft's Perlin noise wrapping method.

## Status

Prototype build target: Minecraft `26.2`, NeoForge `26.2.0.6-beta`.

## Credits

Inspired by and behaviorally based on AdyTech99's MIT-licensed **Farlands Reborn**, whose core idea is to undo Mojang's far-coordinate Perlin noise precision wrapping.

## Build

```bash
./gradlew build
python scripts/verify_artifact.py
```

## Test in-game

1. Install the built jar from `build/libs/` into a Minecraft `26.2` NeoForge instance.
2. Generate a new world.
3. Teleport near the historical Far Lands threshold:

```mcfunction
/tp @s 12550821 120 0
```

Also test Z-axis and negative coordinates:

```mcfunction
/tp @s 0 120 12550821
/tp @s -12550821 120 0
```

Expected: distorted Far Lands-style terrain appears beyond/around the threshold.
