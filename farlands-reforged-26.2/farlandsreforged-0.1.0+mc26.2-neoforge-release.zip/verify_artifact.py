import sys
import zipfile
from pathlib import Path

jar = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('build/libs/farlandsreforged-0.1.0+mc26.2-neoforge.jar')
mc_artifact = Path('build/moddev/artifacts/minecraft-patched-26.2.0.6-beta.jar')
required_entries = {
    'META-INF/neoforge.mods.toml',
    'farlandsreforged.mixins.json',
    'com/shigeo/farlandsreforged/FarlandsReforged.class',
    'com/shigeo/farlandsreforged/mixin/PerlinNoiseMixin.class',
}

if not jar.exists():
    raise SystemExit(f'Artifact missing: {jar}')

with zipfile.ZipFile(jar) as zf:
    names = set(zf.namelist())
    missing = sorted(required_entries - names)
    if missing:
        raise SystemExit('Missing required jar entries: ' + ', '.join(missing))
    if 'pack.mcmeta' in names:
        raise SystemExit('Runtime jar should not include pack.mcmeta; this code-only mod does not need a resource pack.')
    mods_toml = zf.read('META-INF/neoforge.mods.toml').decode('utf-8')
    mixins = zf.read('farlandsreforged.mixins.json').decode('utf-8')

expected_text = [
    'modId = "farlandsreforged"',
    'version = "0.1.0+mc26.2-neoforge"',
    'versionRange = "[26.2,26.3)"',
    'config = "farlandsreforged.mixins.json"',
    'PerlinNoiseMixin',
    'JAVA_25',
]
combined = mods_toml + '\n' + mixins
missing_text = [t for t in expected_text if t not in combined]
if missing_text:
    raise SystemExit('Missing expected metadata text: ' + ', '.join(missing_text))

if mc_artifact.exists():
    with zipfile.ZipFile(mc_artifact) as zf:
        cls = zf.read('net/minecraft/world/level/levelgen/synth/PerlinNoise.class')
    # Constant-pool smoke check: the target method name and descriptor still exist in Minecraft 26.2.
    if b'wrap' not in cls or b'(D)D' not in cls:
        raise SystemExit('Minecraft 26.2 PerlinNoise no longer appears to expose wrap(D)D; mixin target needs remapping.')

print(f'OK: {jar} contains required NeoForge metadata, mixin config, compiled classes, and targets PerlinNoise.wrap(D)D.')
